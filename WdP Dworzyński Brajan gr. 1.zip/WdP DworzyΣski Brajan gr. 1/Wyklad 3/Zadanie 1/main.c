#include <stdio.h>
#include <float.h>


int main(void)
{
  float p=1.e123;
  p=p*1.0e1;

  printf("Najpierw sprawdzmy rozmiary typow integer i float w bajtach:\n");
  printf("Rozmiar int (w bajtach): %d\n", sizeof (int));
  printf("Rozmiar float (w bajtach): %d\n", sizeof (float));
  printf("Przepelnienie integer, czyli 2147483647 + 1 = %d\n",2147483647+1 );
  printf("Niedopelnienie float, czyli 1.0e-37 / 10 = %f\n", 1.0e-37/10);
  printf("Przepelnienie float, czyli 1.0e38 * 10= %f\n",p);
    return 0;
}
