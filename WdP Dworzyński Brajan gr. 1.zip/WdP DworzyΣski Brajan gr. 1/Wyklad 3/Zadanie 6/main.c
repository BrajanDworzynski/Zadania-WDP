#include <stdio.h>

int main(void)
{
  double masaa=3.0e-23;
  int masab=1000;
  double ob;
  double li;
  printf("Podaj ob wody w litrach:\n");
  scanf("%lf", &ob);
  li=ob*masab/masaa;
  printf("Znajduje sie %.2le czasteczek wody.\n", li);
  return 0;
}
