#include <stdio.h>

int main(void)
{
  int kod;

  printf("Podaj kod ASCII: \n");
  scanf("%d", &kod);
  printf("%c\n", kod);

  return 0;
}
