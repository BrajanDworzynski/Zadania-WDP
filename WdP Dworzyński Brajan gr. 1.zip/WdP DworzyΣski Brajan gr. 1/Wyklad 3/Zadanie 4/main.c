#include <stdio.h>

int main(void)
{
  float liczba;

  printf("Podaj liczbe zmiennoprzecinkowa:\n");
  scanf("%f", &liczba);
  printf("%f lub %e\n", liczba, liczba);

  return 0;
}
