#include <stdio.h>

int main(void)
{
  printf("%c\n", '\a');
  printf("Sally, przerazona niespodziewanym odglosem, krzyknela \"A niech mnie, "
	  "co to\nbylo!?\n");
 return 0;
}
