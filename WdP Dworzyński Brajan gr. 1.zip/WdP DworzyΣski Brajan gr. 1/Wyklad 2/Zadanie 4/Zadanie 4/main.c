#include <stdio.h>
#include <stdlib.h>

int main(void)
{
    printf("Panie Janie!\n");
abc();
abcd();
return 0;
}
void abc(void)
{
printf("Panie Janie!\n");
}
void abcd(void)
{
    printf("Rano Wstan!");
}


