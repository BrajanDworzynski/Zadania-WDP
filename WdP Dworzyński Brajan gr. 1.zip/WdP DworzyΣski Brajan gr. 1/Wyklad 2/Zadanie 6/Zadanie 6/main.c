#include <stdio.h>
#include <stdlib.h>

int main()
{
us();
us();
us();
printf("\n");
us();
us();
printf("\n");
us();
}
void us(void)
{
    printf("Usmiech!");
}
