#include <stdio.h>
#include <stdlib.h>

int main()
{
    printf("Imie: Brajan\n");
    printf("Nazwisko: Dworzynski\n");
    printf("Ulica: Francziszka Barcza\n");\
    printf("Kod pocztowy: 10-685\n");
    printf("Miasto: Olsztyn");
    return 0;
}
