#include <stdio.h>
#include <stdlib.h>

int main()
{
    printf("Brajan Dworzynski\n");
    printf("Brajan \nDworzynski\n");
    printf("Brajan ");
    printf("Dworzynski");
    return 0;
}
