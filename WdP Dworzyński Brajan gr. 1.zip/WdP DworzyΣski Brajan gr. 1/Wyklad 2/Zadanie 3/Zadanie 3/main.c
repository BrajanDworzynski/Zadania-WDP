#include <stdio.h>
#include <stdlib.h>

int main()
{
    int wiek;
    int dni;
    wiek=19;
    dni=wiek*365;
    printf("Mam %d lat\n",wiek);
    printf("A wiec mam %d dni",dni);
    return 0;
}
