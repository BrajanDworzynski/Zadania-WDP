#include <stdio.h>
#include <stdlib.h>

int main()
{
    int liczba;
    liczba=10;
    int podwojona;
    podwojona=liczba*2;
    int kwadrat;
    kwadrat=liczba*liczba;
    printf("Liczba %d\n", liczba);
    printf("Podwojona liczba %d to %d\n", liczba, podwojona);
    printf("Liczba %d podniesiona do kwadratu to %d\n", liczba, kwadrat);
    return 0;
}
