#include <stdio.h>
#include <string.h>
#define MAXDL 40
int main(void)
{
  char i[MAXDL];
  char n[MAXDL];
  printf("Imie i nazwisko:");
  scanf("%s %s", i, n);
  printf("%s %s\n",i, n);
  printf("%*d %*d\n", strlen(i), strlen(i), strlen(n),strlen(n));
  printf("%s %s\n",i, n);
  printf("%-*d %-*d\n", strlen(i), strlen(i), strlen(n),strlen(n));
  return 0;
}
