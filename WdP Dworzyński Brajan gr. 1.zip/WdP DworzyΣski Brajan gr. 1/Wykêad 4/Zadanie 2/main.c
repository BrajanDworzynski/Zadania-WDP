#include <stdio.h>
#include <string.h>
#define IMIE_DL 40

int main(void)
{
  char i[IMIE_DL];
  printf("Podaj swoje imie:");
  scanf("%s", i);
  printf("\"%s\"\n", i);
  printf("\"%20s\"\n", i);
  printf("\"%-20s\"\n", i);
  printf("%*s\n",strlen(i)+3, i);
  return 0;
}
