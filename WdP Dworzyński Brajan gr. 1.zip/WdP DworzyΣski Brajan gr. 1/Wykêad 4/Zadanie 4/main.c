#include <stdio.h>

int main(void)
{
  char i[20];
  int w;
  printf("Twoj wzrost:");
  scanf("%d", &w);
  printf("Twoje imie:");
  scanf("%s", i);
  printf("%s, masz %.2f metra wzrostu.\n", i, w/100.0);
  return 0;
}
