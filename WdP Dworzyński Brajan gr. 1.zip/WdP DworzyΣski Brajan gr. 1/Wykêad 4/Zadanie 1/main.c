
#include <stdio.h>
#define MAXDL 40

int main(void)
{
  char imie[MAXDL];
  char nazwisko[MAXDL];
  printf("Imie:");
  scanf("%s", imie);
  printf("Nazwisko:");
  scanf("%s", nazwisko);
  printf("Imie i nazwisko::\n");
  printf("%s, %s\n\n", nazwisko, imie);
  return 0;
}
