#include <stdio.h>
int main(void)
{
  float l;
  printf("Podaj liczbe:");
  scanf("%f", &l);
  printf("Wpisano liczbe %.1f lub %.1e\n", l, l);
  printf("Wpisano liczbe %+.3f lub %.3E\n", l, l);
  return 0;
}
